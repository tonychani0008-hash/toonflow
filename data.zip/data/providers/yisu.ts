type MediaInput =
  | { type: "url"; url: string; mimeType?: string }
  | { type: "base64"; data: string; mimeType: string }
  | { type: "binary"; data: Uint8Array; mimeType: string };

type VideoRequest = {
  model: string;
  prompt: string;
  images?: MediaInput[];
  videos?: MediaInput[];
  audios?: MediaInput[];
  firstFrame?: MediaInput;
  lastFrame?: MediaInput;
  mode?: string | string[];
  duration?: number;
  resolution?: string;
  ratio?: string;
  generateAudio?: boolean;
  watermark?: boolean;
  other?: Record<string, unknown>;
};

type Context = {
  config: { apiKey?: string };
  signal?: AbortSignal;
  tool: { fetch: typeof fetch; errorMessage(value: unknown): string };
};

type VideoTask = {
  id?: string;
  status?: string;
  content?: { video_url?: string };
  error?: unknown;
};

function imageUrl(input: MediaInput) {
  if (input.type === "url") {
    const url = new URL(input.url);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) throw new Error("参考图片须为不含账号密码的 HTTP(S) 地址");
    return url.href;
  }
  const encoded = input.type === "binary" ? Buffer.from(input.data).toString("base64") : input.data;
  const match = /^data:([^;,]+);base64,([\s\S]+)$/.exec(encoded);
  const mimeType = match?.[1] ?? input.mimeType;
  const data = (match?.[2] ?? encoded).replace(/\s/g, "");
  if (!/^image\/(?:png|jpeg|webp|bmp|tiff|gif|heic|heif)$/i.test(mimeType)) throw new Error("参考图片格式不受 Yisu 支持");
  if (!data || !/^[A-Za-z0-9+/]*={0,2}$/.test(data) || data.length % 4 === 1) throw new Error("参考图片 Base64 无效");
  const size = Buffer.from(data, "base64").byteLength;
  if (!size || size >= 30 * 1024 * 1024) throw new Error("每张参考图片须非空且小于 30 MB");
  return `data:${mimeType};base64,${data}`;
}

function wait(signal: AbortSignal, milliseconds: number) {
  signal.throwIfAborted();
  return new Promise<void>((resolve, reject) => {
    const abort = () => {
      clearTimeout(timer);
      reject(signal.reason);
    };
    const timer = setTimeout(() => {
      signal.removeEventListener("abort", abort);
      resolve();
    }, milliseconds);
    signal.addEventListener("abort", abort, { once: true });
  });
}

async function requestTask(context: Context, apiKey: string, path: string, signal: AbortSignal, body?: string): Promise<VideoTask> {
  const response = await context.tool.fetch(`https://yisu-api.gigaai.cc/api/v3/contents/generations/tasks${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: { Authorization: `Bearer ${apiKey}`, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
    body,
    redirect: "error",
    signal: AbortSignal.any([signal, AbortSignal.timeout(60000)]),
  });
  const text = await response.text();
  let data: VideoTask;
  try { data = JSON.parse(text); }
  catch { throw Object.assign(new Error(`Yisu 未返回有效 JSON（HTTP ${response.status}）`), { status: response.status }); }
  if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("Yisu 任务响应格式无效");
  if (!response.ok || data.error) throw Object.assign(new Error(context.tool.errorMessage(data) || `Yisu 请求失败（HTTP ${response.status}）`), { status: response.status });
  return data;
}

export default {
  id: "yisu",
  label: "Yisu",
  version: "2.0.0",
  readme: "[Yisu 接口文档](https://yisu-api.gigaai.cc/docs)。Seedance 2.5 支持 4～30 秒、480p/720p/1080p；此适配器支持文生视频及最多 30 张图片参考。创建任务仅提交一次，内部轮询完成后返回 MP4。",
  rules: [{
    type: "input",
    field: "apiKey",
    title: "API Key",
    value: "",
    props: { type: "password", showPassword: true, autocomplete: "off" },
    validate: [{ required: true, message: "请填写 Yisu API Key", trigger: "blur" }],
  }],
  models: [
    {
      "id": "doubao-seedance-2-5-260628",
      "label": "Seedance 2.5",
      "type": "video",
      "mode": [
        "text",
        [
          "imageReference:30"
        ]
      ],
      "audio": "optional",
      "durationResolutionMap": [
        {
          "duration": [
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30
          ],
          "resolution": [
            "480p",
            "720p",
            "1080p"
          ]
        }
      ]
    }
  ],
  async generateVideo(this: Context, request: VideoRequest) {
    const apiKey = this.config.apiKey?.trim();
    if (!apiKey) throw new Error("请在媒体模型设置中填写 Yisu API Key");
    if (request.model !== "doubao-seedance-2-5-260628") throw new Error("此适配器仅支持 Seedance 2.5");
    if (typeof request.prompt !== "string" || !request.prompt.trim()) throw new Error("请输入视频提示词");
    if (request.firstFrame || request.lastFrame || request.videos?.length || request.audios?.length) throw new Error("此适配器使用图片参考模式，不支持首尾帧、参考视频或参考音频");
    if (request.other && Object.keys(request.other).length) throw new Error("此适配器没有额外自定义参数");
    const images = request.images ?? [];
    if (images.length > 30) throw new Error("Seedance 2.5 最多支持 30 张参考图");
    if (request.mode === "text" && images.length) throw new Error("文生视频模式不能同时使用参考图，请选择图片参考模式");
    if (typeof request.mode === "string" && request.mode !== "text") throw new Error("请选择文生视频或图片参考模式");
    if (Array.isArray(request.mode) && request.mode.some(mode => !/^imageReference:(?:[1-9]|[12]\d|30)$/.test(mode))) throw new Error("此适配器仅支持图片参考");
    const duration = request.duration ?? 4;
    if (!Number.isInteger(duration) || duration < 4 || duration > 30) throw new Error("Seedance 2.5 时长必须为 4～30 秒的整数");
    const resolution = request.resolution ?? "480p";
    if (!["480p", "720p", "1080p"].includes(resolution)) throw new Error("Seedance 2.5 分辨率仅支持 480p、720p、1080p");
    const ratio = request.ratio ?? "16:9";
    if (!["16:9", "9:16", "1:1", "4:3", "3:4", "21:9", "adaptive"].includes(ratio)) throw new Error("Yisu 不支持所选视频比例");
    const body = JSON.stringify({
      model: request.model,
      content: [
        { type: "text", text: request.prompt.trim() },
        ...images.map(input => ({ type: "image_url", image_url: { url: imageUrl(input) }, role: "reference_image" })),
      ],
      duration, resolution, ratio,
      generate_audio: request.generateAudio ?? false,
      watermark: request.watermark ?? false,
      ...(images.length ? { omni_reference_task_type: "reference" } : {}),
      output_format: "mp4",
    });
    if (Buffer.byteLength(body) > 64 * 1024 * 1024) throw new Error("参考图片编码后的请求体不能超过 64 MB");
    const signal = AbortSignal.any([AbortSignal.timeout(15 * 60_000), ...(this.signal ? [this.signal] : [])]);
    const created = await requestTask(this, apiKey, "", signal, body);
    const taskId = created.id;
    if (typeof taskId !== "string" || !taskId.trim()) throw new Error("Yisu 创建响应未返回任务 ID");
    let failures = 0;
    // ACT: 同一任务最多等待 15 分钟；查询失败可继续查询，绝不自动重提交付费生成请求。
    try {
      while (true) {
        await wait(signal, 5000);
        let task: VideoTask;
        try {
          task = await requestTask(this, apiKey, `/${encodeURIComponent(taskId)}`, signal);
          failures = 0;
        } catch (cause) {
          signal.throwIfAborted();
          const status = (cause as { status?: number }).status;
          if ((status === undefined || status === 429 || status >= 500) && ++failures <= 3) continue;
          throw cause;
        }
        if (task.status === "succeeded") {
          const url = task.content?.video_url;
          if (typeof url !== "string" || !/^https?:\/\//i.test(url)) throw new Error("Yisu 任务成功但没有返回有效的视频地址");
          return [{ mediaType: "video" as const, type: "url" as const, url, mimeType: "video/mp4" }];
        }
        if (["failed", "cancelled", "expired"].includes(task.status ?? "")) throw new Error(this.tool.errorMessage(task) || `Yisu 任务状态：${task.status}`);
        if (!["queued", "running"].includes(task.status ?? "")) throw new Error(`Yisu 返回未知任务状态：${task.status ?? "空"}`);
      }
    } catch (cause) {
      const reason = signal.aborted ? "视频等待超时或已取消" : this.tool.errorMessage(cause) || "视频查询失败";
      throw new Error(`${reason}。Yisu 任务 ID：${taskId}；请查询原任务，不要重复生成。`);
    }
  },
};
